package org.example.cursosapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CursosApiApplicationTests {

    @Test
    void contextLoads() {
    }

}
