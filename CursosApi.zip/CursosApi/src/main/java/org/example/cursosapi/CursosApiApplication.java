package org.example.cursosapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CursosApiApplication {

    public static void main(String[] args) {
        SpringApplication.run(CursosApiApplication.class, args);
    }

}
