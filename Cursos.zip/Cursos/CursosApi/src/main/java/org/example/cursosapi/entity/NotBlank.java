package org.example.cursosapi.entity;

public @interface NotBlank {

}
