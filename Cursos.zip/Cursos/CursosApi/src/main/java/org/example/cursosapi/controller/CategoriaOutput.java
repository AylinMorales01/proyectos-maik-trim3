package org.example.cursosapi.controller;

public class CategoriaOutput {

}
